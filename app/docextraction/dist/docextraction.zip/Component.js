sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("docextraction.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map